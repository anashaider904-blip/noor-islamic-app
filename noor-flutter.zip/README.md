# Noor - Islamic App (Flutter)

A complete, native Flutter app (not a WebView wrapper) for Android and iOS:

- **Home** — Gregorian + Hijri date, live next-prayer countdown, Ayah of the Day, Hadith of the Day, quick buttons
- **Quran** — all 114 Surahs, Uthmani Arabic + English (Asad) + Urdu (Jalandhry) per ayah, last-read bookmark
- **Tasbeeh** — big counter with vibration, preset dhikr, 33/100/1000 targets, daily + lifetime counts saved
- **Qibla** — bearing + distance to the Kaaba for your city, compass-style dial
- **More** — Prayer times & city picker, prayer tracker, Zakat calculator (PKR/USD/SAR), Masnoon duas, settings (dark mode, EN/UR/AR, Quran font size)

Prayer times come from the Aladhan API and Quran text from the AlQuran Cloud API.
Bookmarks, tasbeeh counts, prayer tracker and settings are saved on the phone with `shared_preferences`.

Colours: Deep Emerald `#0B3D2E`, Gold `#C9A227`, cream. Dark and light mode.

This folder intentionally has **no `android/` or `ios/` folder** — the cloud build
generates them with `flutter create .`, which keeps `lib/main.dart` untouched.

---

## Option A — Codemagic (recommended, easiest from a phone)

Free tier: **500 free build minutes per month, no credit card needed.**
One APK build takes roughly 10–15 minutes, so it is comfortably free.

1. Put this project in a GitHub repository (upload the contents of this folder,
   keeping `lib/main.dart`, `pubspec.yaml` and `codemagic.yaml` at the top level).
2. Go to **codemagic.io**, sign up free with your GitHub account.
3. **Add application** → select the repository. Codemagic detects `codemagic.yaml`.
4. Start the **android-release** workflow.
5. When the build finishes (green), open it and download the artifact
   **`app-release.apk`**.
6. Transfer/open that APK on your Android phone and install it
   (the phone may ask to allow installing from that source — allow it).

## Option B — GitHub Actions (also free)

Free: GitHub Actions is free for public repositories, and private repositories
get free build minutes every month — more than enough for this app.

1. Put this project in a GitHub repository (the workflow is already in
   `.github/workflows/build-apk.yml`).
2. In the repo, open the **Actions** tab → **Build Noor APK** → **Run workflow**.
3. Wait for the green tick, open the finished run, and download the artifact
   named **`noor-app-release-apk`** (a zip containing `app-release.apk`).
4. Unzip it on your phone, tap `app-release.apk`, and install.

## Notes

- **Android:** the APK from either service installs directly on any Android phone.
- **iOS:** building an installable iPhone app needs an Apple Developer account
  ($99/year) and signing in Codemagic/Xcode Cloud — the Android APK above needs neither.
- **Publishing to Google Play** is separate and optional: Google charges a one-time
  $25 developer fee. Downloading and installing the APK yourself is free.
- If a build fails on `flutter create`, check that `pubspec.yaml` and
  `lib/main.dart` are at the repository root, not inside an extra folder.
