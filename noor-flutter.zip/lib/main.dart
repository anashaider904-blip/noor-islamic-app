import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Noor - Islamic App. One self-contained file.
// Colours: Deep Emerald #0B3D2E, Gold #C9A227, cream.
// Data: Aladhan API (prayer times + Hijri), AlQuran Cloud API (Quran text).
// Local storage: shared_preferences (settings, bookmarks, tasbeeh, tracker).
// ---------------------------------------------------------------------------

const Color kEmerald = Color(0xFF0B3D2E);
const Color kEmeraldLight = Color(0xFF12503C);
const Color kGold = Color(0xFFC9A227);
const Color kCream = Color(0xFFFFF8E7);

void main() {
  runApp(const NoorApp());
}

// ------------------------------- Static data -------------------------------

class City {
  final String name;
  final String country;
  final double lat;
  final double lng;
  const City(this.name, this.country, this.lat, this.lng);
}

const List<City> kCities = <City>[
  City('Karachi', 'Pakistan', 24.8607, 67.0011),
  City('Lahore', 'Pakistan', 31.5497, 74.3436),
  City('Islamabad', 'Pakistan', 33.7294, 73.0931),
  City('Makkah', 'Saudi Arabia', 21.4225, 39.8262),
  City('Madinah', 'Saudi Arabia', 24.5247, 39.5692),
  City('Dubai', 'United Arab Emirates', 25.2048, 55.2708),
  City('London', 'United Kingdom', 51.5074, -0.1278),
];

class SurahInfo {
  final int number;
  final String english;
  final String arabic;
  final int ayahs;
  const SurahInfo(this.number, this.english, this.arabic, this.ayahs);
}

const List<SurahInfo> kSurahs = <SurahInfo>[
  SurahInfo(1, 'Al-Faatiha', 'الفاتحة', 7),
  SurahInfo(2, 'Al-Baqara', 'البقرة', 286),
  SurahInfo(3, 'Aal-e-Imran', 'آل عمران', 200),
  SurahInfo(4, 'An-Nisaa', 'النساء', 176),
  SurahInfo(5, 'Al-Maaida', 'المائدة', 120),
  SurahInfo(6, "Al-An'aam", 'الأنعام', 165),
  SurahInfo(7, "Al-A'raaf", 'الأعراف', 206),
  SurahInfo(8, 'Al-Anfaal', 'الأنفال', 75),
  SurahInfo(9, 'At-Tawba', 'التوبة', 129),
  SurahInfo(10, 'Yunus', 'يونس', 109),
  SurahInfo(11, 'Hud', 'هود', 123),
  SurahInfo(12, 'Yusuf', 'يوسف', 111),
  SurahInfo(13, "Ar-Ra'd", 'الرعد', 43),
  SurahInfo(14, 'Ibrahim', 'إبراهيم', 52),
  SurahInfo(15, 'Al-Hijr', 'الحجر', 99),
  SurahInfo(16, 'An-Nahl', 'النحل', 128),
  SurahInfo(17, 'Al-Israa', 'الإسراء', 111),
  SurahInfo(18, 'Al-Kahf', 'الكهف', 110),
  SurahInfo(19, 'Maryam', 'مريم', 98),
  SurahInfo(20, 'Taa-Haa', 'طه', 135),
  SurahInfo(21, 'Al-Anbiyaa', 'الأنبياء', 112),
  SurahInfo(22, 'Al-Hajj', 'الحج', 78),
  SurahInfo(23, "Al-Mu'minun", 'المؤمنون', 118),
  SurahInfo(24, 'An-Nur', 'النور', 64),
  SurahInfo(25, 'Al-Furqaan', 'الفرقان', 77),
  SurahInfo(26, "Ash-Shu'araa", 'الشعراء', 227),
  SurahInfo(27, 'An-Naml', 'النمل', 93),
  SurahInfo(28, 'Al-Qasas', 'القصص', 88),
  SurahInfo(29, 'Al-Ankabut', 'العنكبوت', 69),
  SurahInfo(30, 'Ar-Rum', 'الروم', 60),
  SurahInfo(31, 'Luqman', 'لقمان', 34),
  SurahInfo(32, 'As-Sajda', 'السجدة', 30),
  SurahInfo(33, 'Al-Ahzaab', 'الأحزاب', 73),
  SurahInfo(34, 'Saba', 'سبأ', 54),
  SurahInfo(35, 'Faatir', 'فاطر', 45),
  SurahInfo(36, 'Yaa-Sin', 'يس', 83),
  SurahInfo(37, 'As-Saaffaat', 'الصافات', 182),
  SurahInfo(38, 'Saad', 'ص', 88),
  SurahInfo(39, 'Az-Zumar', 'الزمر', 75),
  SurahInfo(40, 'Ghaafir', 'غافر', 85),
  SurahInfo(41, 'Fussilat', 'فصلت', 54),
  SurahInfo(42, 'Ash-Shura', 'الشورى', 53),
  SurahInfo(43, 'Az-Zukhruf', 'الزخرف', 89),
  SurahInfo(44, 'Ad-Dukhaan', 'الدخان', 59),
  SurahInfo(45, 'Al-Jaathiya', 'الجاثية', 37),
  SurahInfo(46, 'Al-Ahqaf', 'الأحقاف', 35),
  SurahInfo(47, 'Muhammad', 'محمد', 38),
  SurahInfo(48, 'Al-Fath', 'الفتح', 29),
  SurahInfo(49, 'Al-Hujuraat', 'الحجرات', 18),
  SurahInfo(50, 'Qaaf', 'ق', 45),
  SurahInfo(51, 'Adh-Dhaariyaat', 'الذاريات', 60),
  SurahInfo(52, 'At-Tur', 'الطور', 49),
  SurahInfo(53, 'An-Najm', 'النجم', 62),
  SurahInfo(54, 'Al-Qamar', 'القمر', 55),
  SurahInfo(55, 'Ar-Rahmaan', 'الرحمن', 78),
  SurahInfo(56, "Al-Waaqi'a", 'الواقعة', 96),
  SurahInfo(57, 'Al-Hadid', 'الحديد', 29),
  SurahInfo(58, 'Al-Mujaadila', 'المجادلة', 22),
  SurahInfo(59, 'Al-Hashr', 'الحشر', 24),
  SurahInfo(60, 'Al-Mumtahana', 'الممتحنة', 13),
  SurahInfo(61, 'As-Saff', 'الصف', 14),
  SurahInfo(62, "Al-Jumu'a", 'الجمعة', 11),
  SurahInfo(63, 'Al-Munaafiqun', 'المنافقون', 11),
  SurahInfo(64, 'At-Taghaabun', 'التغابن', 18),
  SurahInfo(65, 'At-Talaaq', 'الطلاق', 12),
  SurahInfo(66, 'At-Tahrim', 'التحريم', 12),
  SurahInfo(67, 'Al-Mulk', 'الملك', 30),
  SurahInfo(68, 'Al-Qalam', 'القلم', 52),
  SurahInfo(69, 'Al-Haaqqa', 'الحاقة', 52),
  SurahInfo(70, "Al-Ma'aarij", 'المعارج', 44),
  SurahInfo(71, 'Nuh', 'نوح', 28),
  SurahInfo(72, 'Al-Jinn', 'الجن', 28),
  SurahInfo(73, 'Al-Muzzammil', 'المزمل', 20),
  SurahInfo(74, 'Al-Muddaththir', 'المدثر', 56),
  SurahInfo(75, 'Al-Qiyaama', 'القيامة', 40),
  SurahInfo(76, 'Al-Insaan', 'الإنسان', 31),
  SurahInfo(77, 'Al-Mursalaat', 'المرسلات', 50),
  SurahInfo(78, 'An-Naba', 'النبأ', 40),
  SurahInfo(79, "An-Naazi'aat", 'النازعات', 46),
  SurahInfo(80, 'Abasa', 'عبس', 42),
  SurahInfo(81, 'At-Takwir', 'التكوير', 29),
  SurahInfo(82, 'Al-Infitaar', 'الانفطار', 19),
  SurahInfo(83, 'Al-Mutaffifin', 'المطففين', 36),
  SurahInfo(84, 'Al-Inshiqaaq', 'الانشقاق', 25),
  SurahInfo(85, 'Al-Buruj', 'البروج', 22),
  SurahInfo(86, 'At-Taariq', 'الطارق', 17),
  SurahInfo(87, "Al-A'laa", 'الأعلى', 19),
  SurahInfo(88, 'Al-Ghaashiya', 'الغاشية', 26),
  SurahInfo(89, 'Al-Fajr', 'الفجر', 30),
  SurahInfo(90, 'Al-Balad', 'البلد', 20),
  SurahInfo(91, 'Ash-Shams', 'الشمس', 15),
  SurahInfo(92, 'Al-Layl', 'الليل', 21),
  SurahInfo(93, 'Ad-Duhaa', 'الضحى', 11),
  SurahInfo(94, 'Ash-Sharh', 'الشرح', 8),
  SurahInfo(95, 'At-Tin', 'التين', 8),
  SurahInfo(96, 'Al-Alaq', 'العلق', 19),
  SurahInfo(97, 'Al-Qadr', 'القدر', 5),
  SurahInfo(98, 'Al-Bayyina', 'البينة', 8),
  SurahInfo(99, 'Az-Zalzala', 'الزلزلة', 8),
  SurahInfo(100, 'Al-Aadiyaat', 'العاديات', 11),
  SurahInfo(101, "Al-Qaari'a", 'القارعة', 11),
  SurahInfo(102, 'At-Takaathur', 'التكاثر', 8),
  SurahInfo(103, 'Al-Asr', 'العصر', 3),
  SurahInfo(104, 'Al-Humaza', 'الهمزة', 9),
  SurahInfo(105, 'Al-Fil', 'الفيل', 5),
  SurahInfo(106, 'Quraysh', 'قريش', 4),
  SurahInfo(107, "Al-Maa'un", 'الماعون', 7),
  SurahInfo(108, 'Al-Kawthar', 'الكوثر', 3),
  SurahInfo(109, 'Al-Kaafirun', 'الكافرون', 6),
  SurahInfo(110, 'An-Nasr', 'النصر', 3),
  SurahInfo(111, 'Al-Masad', 'المسد', 5),
  SurahInfo(112, 'Al-Ikhlaas', 'الإخلاص', 4),
  SurahInfo(113, 'Al-Falaq', 'الفلق', 5),
  SurahInfo(114, 'An-Naas', 'الناس', 6),
];

class Dua {
  final String title;
  final String arabic;
  final String urdu;
  final String english;
  const Dua(this.title, this.arabic, this.urdu, this.english);
}

const List<Dua> kDuas = <Dua>[
  Dua(
    'Waking Up',
    'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ',
    'تمام تعریفیں اللہ کے لیے ہیں جس نے ہمیں موت (نیند) کے بعد زندگی دی اور اسی کی طرف لوٹ کر جانا ہے۔',
    'All praise is for Allah who gave us life after causing us to die (sleep), and to Him is the resurrection.',
  ),
  Dua(
    'Before Sleeping',
    'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
    'اے اللہ! تیرے نام کے ساتھ میں مرتا (سوتا) ہوں اور جیتا (جاگتا) ہوں۔',
    'In Your name, O Allah, I die and I live.',
  ),
  Dua(
    'Before Eating',
    'بِسْمِ اللَّهِ وَعَلَى بَرَكَةِ اللَّهِ',
    'اللہ کے نام سے اور اللہ کی برکت کے ساتھ (کھانا شروع کرتا ہوں)۔',
    'In the name of Allah and with the blessings of Allah (I begin eating).',
  ),
  Dua(
    'After Eating',
    'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ',
    'تمام تعریفیں اللہ کے لیے ہیں جس نے ہمیں کھلایا، پلایا اور ہمیں مسلمان بنایا۔',
    'All praise is for Allah who fed us, gave us drink, and made us Muslims.',
  ),
  Dua(
    'Entering the Masjid',
    'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ',
    'اے اللہ! میرے لیے اپنی رحمت کے دروازے کھول دے۔',
    'O Allah, open for me the doors of Your mercy.',
  ),
  Dua(
    'Leaving the Masjid',
    'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ',
    'اے اللہ! میں تجھ سے تیرے فضل کا سوال کرتا ہوں۔',
    'O Allah, I ask You for Your bounty.',
  ),
  Dua(
    'Travelling',
    'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ',
    'پاک ہے وہ ذات جس نے اس (سواری) کو ہمارے تابع کر دیا، ورنہ ہم اسے قابو میں لانے والے نہ تھے، اور یقیناً ہم اپنے رب کی طرف لوٹنے والے ہیں۔',
    'Glory to Him who has subjected this to us, though we could never have it by our efforts; and truly to our Lord we are returning.',
  ),
  Dua(
    'For Parents',
    'رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا',
    'اے میرے رب! میرے والدین پر رحم فرما جس طرح انہوں نے بچپن میں میری پرورش کی۔',
    'My Lord, have mercy upon my parents as they raised me when I was small. (Quran 17:24)',
  ),
  Dua(
    'Seeking Forgiveness',
    'رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ',
    'اے ہمارے رب! ہم نے اپنی جانوں پر ظلم کیا، اور اگر تو ہمیں نہ بخشے اور ہم پر رحم نہ کرے تو ہم خسارہ پانے والوں میں سے ہو جائیں گے۔',
    'Our Lord, we have wronged ourselves; and if You do not forgive us and have mercy upon us, we will surely be among the losers. (Quran 7:23)',
  ),
  Dua(
    'For This World and the Next',
    'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ',
    'اے ہمارے رب! ہمیں دنیا میں بھی بھلائی عطا فرما اور آخرت میں بھی بھلائی، اور ہمیں آگ کے عذاب سے بچا۔',
    'Our Lord, give us good in this world and good in the Hereafter, and shield us from the punishment of the Fire. (Quran 2:201)',
  ),
];

class DayText {
  final String arabic;
  final String english;
  final String urdu;
  final String ref;
  const DayText(this.arabic, this.english, this.urdu, this.ref);
}

const List<DayText> kAyahsOfDay = <DayText>[
  DayText(
    'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    'Indeed, with hardship comes ease.',
    'بے شک تنگی کے ساتھ آسانی ہے۔',
    'Surah Ash-Sharh 94:6',
  ),
  DayText(
    'وَقُل رَّبِّ زِدْنِي عِلْمًا',
    'And say: My Lord, increase me in knowledge.',
    'اور کہو: اے میرے رب! میرے علم میں اضافہ فرما۔',
    'Surah Taha 20:114',
  ),
  DayText(
    'فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ',
    'Indeed I am near. I respond to the call of the caller when he calls upon Me.',
    'میں قریب ہوں، پکارنے والے کی پکار کو جب وہ مجھے پکارے قبول کرتا ہوں۔',
    'Surah Al-Baqarah 2:186',
  ),
  DayText(
    'وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ',
    'And He is with you wherever you are.',
    'اور وہ تمہارے ساتھ ہے جہاں کہیں تم ہو۔',
    'Surah Al-Hadid 57:4',
  ),
];

const List<DayText> kHadithOfDay = <DayText>[
  DayText(
    '',
    'The best among you are those who learn the Quran and teach it.',
    'تم میں سے بہترین وہ ہے جو قرآن سیکھے اور سکھائے۔',
    'Sahih al-Bukhari 5027',
  ),
  DayText(
    '',
    'Actions are but by intentions, and every person shall have only that which he intended.',
    'اعمال کا دارومدار نیتوں پر ہے، اور ہر شخص کو وہی ملے گا جس کی اس نے نیت کی۔',
    'Sahih al-Bukhari 1',
  ),
  DayText(
    '',
    'The most beloved deeds to Allah are those done most consistently, even if small.',
    'اللہ کے نزدیک سب سے پسندیدہ اعمال وہ ہیں جو ہمیشہ کیے جائیں، اگرچہ کم ہوں۔',
    'Sahih al-Bukhari 6464',
  ),
  DayText(
    '',
    'None of you truly believes until he loves for his brother what he loves for himself.',
    'تم میں سے کوئی اس وقت تک مومن نہیں ہو سکتا جب تک اپنے بھائی کے لیے وہی پسند نہ کرے جو اپنے لیے پسند کرتا ہے۔',
    'Sahih al-Bukhari 13',
  ),
];

const List<String> kPrayerNames = <String>[
  'Fajr',
  'Sunrise',
  'Dhuhr',
  'Asr',
  'Maghrib',
  'Isha',
];

// ------------------------------- App root ----------------------------------

class NoorApp extends StatefulWidget {
  const NoorApp({super.key});

  @override
  State<NoorApp> createState() => _NoorAppState();
}

class _NoorAppState extends State<NoorApp> {
  int _tab = 0;
  bool _dark = false;
  String _lang = 'en';
  String _fontSize = 'M';
  int _cityIndex = 0; // Karachi default

  static const Map<String, List<String>> _tabLabels = <String, List<String>>{
    'en': <String>['Home', 'Quran', 'Tasbeeh', 'Qibla', 'More'],
    'ur': <String>['ہوم', 'قرآن', 'تسبیح', 'قبلہ', 'مزید'],
    'ar': <String>['الرئيسية', 'القرآن', 'التسبيح', 'القبلة', 'المزيد'],
  };

  static const Map<String, String> _titles = <String, String>{
    'en': 'Noor - Islamic App',
    'ur': 'نور - اسلامک ایپ',
    'ar': 'نور - التطبيق الإسلامي',
  };

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _dark = prefs.getBool('set_dark') ?? false;
        _lang = prefs.getString('set_lang') ?? 'en';
        _fontSize = prefs.getString('set_font') ?? 'M';
        _cityIndex = prefs.getInt('set_city') ?? 0;
        if (_cityIndex < 0 || _cityIndex >= kCities.length) _cityIndex = 0;
      });
    } catch (_) {
      // Settings are optional; defaults above are used if storage fails.
    }
  }

  Future<void> _saveSetting(String key, Object value) async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      if (value is bool) await prefs.setBool(key, value);
      if (value is String) await prefs.setString(key, value);
      if (value is int) await prefs.setInt(key, value);
    } catch (_) {}
  }

  double get _quranFontSize {
    if (_fontSize == 'S') return 20;
    if (_fontSize == 'L') return 34;
    return 27;
  }

  ThemeData _theme(bool dark) {
    final ColorScheme scheme = dark
        ? const ColorScheme.dark(
            primary: kGold,
            secondary: kGold,
            surface: Color(0xFF0E2A20),
            onSurface: Colors.white,
          )
        : const ColorScheme.light(
            primary: kEmerald,
            secondary: kGold,
            surface: Colors.white,
            onSurface: Color(0xFF1A1A1A),
          );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF071F16) : kCream,
      appBarTheme: const AppBarTheme(
        backgroundColor: kEmerald,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: dark ? const Color(0xFF0E2A20) : Colors.white,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: kGold, width: 0.6),
        ),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: dark ? const Color(0xFF0E2A20) : kEmerald,
        selectedItemColor: kGold,
        unselectedItemColor: Colors.white70,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<String> labels = _tabLabels[_lang] ?? _tabLabels['en']!;
    final City city = kCities[_cityIndex];
    return MaterialApp(
      title: 'Noor - Islamic App',
      debugShowCheckedModeBanner: false,
      theme: _theme(false),
      darkTheme: _theme(true),
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            _titles[_lang] ?? _titles['en']!,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        body: IndexedStack(
          index: _tab,
          children: <Widget>[
            HomeTab(
              city: city,
              cityIndex: _cityIndex,
              onCityChanged: (int i) {
                setState(() => _cityIndex = i);
                _saveSetting('set_city', i);
              },
              goToTab: (int t) => setState(() => _tab = t),
            ),
            QuranTab(quranFontSize: _quranFontSize),
            const TasbeehTab(),
            QiblaTab(city: city),
            MoreTab(
              isDark: _dark,
              lang: _lang,
              fontSize: _fontSize,
              onDarkChanged: (bool v) {
                setState(() => _dark = v);
                _saveSetting('set_dark', v);
              },
              onLangChanged: (String v) {
                setState(() => _lang = v);
                _saveSetting('set_lang', v);
              },
              onFontChanged: (String v) {
                setState(() => _fontSize = v);
                _saveSetting('set_font', v);
              },
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _tab,
          onTap: (int i) => setState(() => _tab = i),
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
                icon: const Icon(Icons.home), label: labels[0]),
            BottomNavigationBarItem(
                icon: const Icon(Icons.menu_book), label: labels[1]),
            BottomNavigationBarItem(
                icon: const Icon(Icons.fingerprint), label: labels[2]),
            BottomNavigationBarItem(
                icon: const Icon(Icons.explore), label: labels[3]),
            BottomNavigationBarItem(
                icon: const Icon(Icons.more_horiz), label: labels[4]),
          ],
        ),
      ),
    );
  }
}

// -------------------------------- Home tab ---------------------------------

class HomeTab extends StatefulWidget {
  final City city;
  final int cityIndex;
  final ValueChanged<int> onCityChanged;
  final ValueChanged<int> goToTab;
  const HomeTab({
    super.key,
    required this.city,
    required this.cityIndex,
    required this.onCityChanged,
    required this.goToTab,
  });

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  Map<String, String> _timings = <String, String>{};
  String _hijri = '';
  bool _loading = true;
  bool _error = false;
  Timer? _timer;
  String _nextName = '';
  String _countdown = '';

  @override
  void initState() {
    super.initState();
    _fetch();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _timings.isNotEmpty) _updateCountdown();
    });
  }

  @override
  void didUpdateWidget(HomeTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.city.name != widget.city.name) _fetch();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  DateTime _parseTime(String hhmm, {int addDays = 0}) {
    final List<String> parts = hhmm.split(':');
    final int h = int.tryParse(parts[0]) ?? 0;
    final int m = parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0;
    final DateTime now = DateTime.now();
    return DateTime(now.year, now.month, now.day + addDays, h, m);
  }

  void _updateCountdown() {
    final DateTime now = DateTime.now();
    String? nextName;
    DateTime? nextTime;
    for (final String name in kPrayerNames) {
      final String? t = _timings[name];
      if (t == null) continue;
      final DateTime dt = _parseTime(t);
      if (dt.isAfter(now)) {
        nextName = name;
        nextTime = dt;
        break;
      }
    }
    if (nextName == null) {
      nextName = 'Fajr';
      final String? t = _timings['Fajr'];
      if (t == null) return;
      nextTime = _parseTime(t, addDays: 1);
    }
    final Duration diff = nextTime!.difference(now);
    String two(int v) => v.toString().padLeft(2, '0');
    setState(() {
      _nextName = nextName!;
      _countdown =
          '${two(diff.inHours)}:${two(diff.inMinutes % 60)}:${two(diff.inSeconds % 60)}';
    });
  }

  Future<void> _fetch() async {
    setState(() {
      _loading = true;
      _error = false;
    });
    try {
      final Uri uri = Uri.https(
        'api.aladhan.com',
        '/v1/timingsByCity',
        <String, String>{
          'city': widget.city.name,
          'country': widget.city.country,
          'method': '2',
        },
      );
      final http.Response res =
          await http.get(uri).timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) throw Exception('bad status');
      final Map<String, dynamic> json =
          jsonDecode(res.body) as Map<String, dynamic>;
      final Map<String, dynamic> data = json['data'] as Map<String, dynamic>;
      final Map<String, dynamic> raw =
          data['timings'] as Map<String, dynamic>;
      final Map<String, String> timings = <String, String>{};
      for (final String name in kPrayerNames) {
        final String v = (raw[name] ?? '').toString();
        timings[name] = v.split(' ').first;
      }
      String hijri = '';
      try {
        final Map<String, dynamic> date =
            data['date'] as Map<String, dynamic>;
        final Map<String, dynamic> h = date['hijri'] as Map<String, dynamic>;
        final Map<String, dynamic> hm = h['month'] as Map<String, dynamic>;
        hijri = '${h['day']} ${hm['en']} ${h['year']} AH';
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _timings = timings;
        _hijri = hijri;
        _loading = false;
      });
      _updateCountdown();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = true;
      });
    }
  }

  String get _gregorian {
    final DateTime n = DateTime.now();
    const List<String> months = <String>[
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December',
    ];
    const List<String> days = <String>[
      'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday',
      'Sunday',
    ];
    return '${days[n.weekday - 1]}, ${n.day} ${months[n.month - 1]} ${n.year}';
  }

  DayText get _ayahOfDay =>
      kAyahsOfDay[DateTime.now().day % kAyahsOfDay.length];
  DayText get _hadithOfDay =>
      kHadithOfDay[DateTime.now().day % kHadithOfDay.length];

  Widget _quickButton(IconData icon, String label, int tab) {
    return InkWell(
      onTap: () => widget.goToTab(tab),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 100,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: kEmerald,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kGold, width: 0.8),
        ),
        child: Column(
          children: <Widget>[
            Icon(icon, color: kGold, size: 26),
            const SizedBox(height: 6),
            Text(label,
                style: const TextStyle(color: Colors.white, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final DayText ayah = _ayahOfDay;
    final DayText hadith = _hadithOfDay;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: <Widget>[
                Text(_gregorian,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold)),
                if (_hijri.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 4),
                  Text(_hijri,
                      style: const TextStyle(
                          fontSize: 15,
                          color: kGold,
                          fontWeight: FontWeight.w600)),
                ],
                const Divider(height: 24),
                if (_loading)
                  const Padding(
                    padding: EdgeInsets.all(12),
                    child: CircularProgressIndicator(color: kGold),
                  )
                else if (_error)
                  Column(
                    children: <Widget>[
                      const Text('Could not load prayer times. '
                          'Check internet and retry.'),
                      const SizedBox(height: 8),
                      ElevatedButton(
                        onPressed: _fetch,
                        child: const Text('Retry'),
                      ),
                    ],
                  )
                else ...<Widget>[
                  Text(
                    _nextName.isEmpty
                        ? 'Next Prayer'
                        : 'Next Prayer: $_nextName',
                    style: const TextStyle(fontSize: 15),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _countdown,
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      color: kEmeraldLight,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: <Widget>[
            const Icon(Icons.location_on, color: kGold, size: 20),
            const SizedBox(width: 6),
            const Text('City: ', style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child: DropdownButton<int>(
                value: widget.cityIndex,
                isExpanded: true,
                underline: const SizedBox(),
                items: List<DropdownMenuItem<int>>.generate(
                  kCities.length,
                  (int i) => DropdownMenuItem<int>(
                    value: i,
                    child: Text('${kCities[i].name}, ${kCities[i].country}'),
                  ),
                ),
                onChanged: (int? v) {
                  if (v != null) widget.onCityChanged(v);
                },
              ),
            ),
          ],
        ),
        if (_timings.isNotEmpty)
          Card(
            child: Column(
              children: kPrayerNames.map((String name) {
                final bool isNext = name == _nextName;
                return ListTile(
                  dense: true,
                  leading: Icon(
                    Icons.access_time,
                    color: isNext ? kGold : null,
                    size: 20,
                  ),
                  title: Text(name,
                      style: TextStyle(
                          fontWeight:
                              isNext ? FontWeight.bold : FontWeight.normal)),
                  trailing: Text(_timings[name] ?? '',
                      style: TextStyle(
                          fontWeight:
                              isNext ? FontWeight.bold : FontWeight.normal,
                          color: isNext ? kGold : null)),
                );
              }).toList(),
            ),
          ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          alignment: WrapAlignment.center,
          children: <Widget>[
            _quickButton(Icons.menu_book, 'Quran', 1),
            _quickButton(Icons.fingerprint, 'Tasbeeh', 2),
            _quickButton(Icons.explore, 'Qibla', 3),
            _quickButton(Icons.volunteer_activism, 'Duas', 4),
            _quickButton(Icons.schedule, 'Prayer Times', 4),
            _quickButton(Icons.calculate, 'Zakat', 4),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: <Color>[kEmerald, kEmeraldLight],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kGold, width: 0.8),
          ),
          padding: const EdgeInsets.all(18),
          child: Column(
            children: <Widget>[
              const Text('Ayah of the Day',
                  style: TextStyle(color: kGold, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text(
                ayah.arabic,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                    color: Colors.white, fontSize: 24, height: 1.7),
              ),
              const SizedBox(height: 8),
              Text(ayah.english,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white)),
              const SizedBox(height: 4),
              Text(ayah.urdu,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 6),
              Text(ayah.ref,
                  style: const TextStyle(color: kGold, fontSize: 12)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('Hadith of the Day',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, color: kGold)),
                const SizedBox(height: 8),
                Text(hadith.english),
                const SizedBox(height: 6),
                Text(hadith.urdu, textDirection: TextDirection.rtl),
                const SizedBox(height: 6),
                Text(hadith.ref,
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// -------------------------------- Quran tab --------------------------------

class QuranTab extends StatefulWidget {
  final double quranFontSize;
  const QuranTab({super.key, required this.quranFontSize});

  @override
  State<QuranTab> createState() => _QuranTabState();
}

class _QuranTabState extends State<QuranTab> {
  String _query = '';
  int? _lastSurah;
  int? _lastAyah;

  @override
  void initState() {
    super.initState();
    _loadLastRead();
  }

  Future<void> _loadLastRead() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _lastSurah = prefs.getInt('last_surah');
        _lastAyah = prefs.getInt('last_ayah');
      });
    } catch (_) {}
  }

  void _openSurah(SurahInfo s) {
    Navigator.of(context)
        .push(
          MaterialPageRoute<void>(
            builder: (_) =>
                SurahReader(surah: s, quranFontSize: widget.quranFontSize),
          ),
        )
        .then((_) => _loadLastRead());
  }

  @override
  Widget build(BuildContext context) {
    final String q = _query.trim().toLowerCase();
    final List<SurahInfo> list = kSurahs.where((SurahInfo s) {
      if (q.isEmpty) return true;
      return s.english.toLowerCase().contains(q) ||
          s.number.toString() == q ||
          s.arabic.contains(_query.trim());
    }).toList();

    SurahInfo? last;
    if (_lastSurah != null &&
        _lastSurah! >= 1 &&
        _lastSurah! <= kSurahs.length) {
      last = kSurahs[_lastSurah! - 1];
    }

    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Search by Surah name, number or Arabic name',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
            ),
            onChanged: (String v) => setState(() => _query = v),
          ),
        ),
        if (last != null)
          Card(
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: ListTile(
              leading: const Icon(Icons.bookmark, color: kGold),
              title: Text('Last Read: ${last.english}'),
              subtitle: Text('Ayah ${_lastAyah ?? 1} of ${last.ayahs}'),
              trailing: const Icon(Icons.arrow_forward),
              onTap: () => _openSurah(last!),
            ),
          ),
        Expanded(
          child: ListView.builder(
            itemCount: list.length,
            itemBuilder: (BuildContext context, int i) {
              final SurahInfo s = list[i];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: kEmerald,
                  child: Text('${s.number}',
                      style:
                          const TextStyle(color: kGold, fontSize: 13)),
                ),
                title: Text(s.english),
                subtitle: Text('${s.ayahs} Ayahs'),
                trailing: Text(s.arabic,
                    style: const TextStyle(fontSize: 18)),
                onTap: () => _openSurah(s),
              );
            },
          ),
        ),
      ],
    );
  }
}

class AyahData {
  final int number;
  final String arabic;
  final String english;
  final String urdu;
  const AyahData(this.number, this.arabic, this.english, this.urdu);
}

class SurahReader extends StatefulWidget {
  final SurahInfo surah;
  final double quranFontSize;
  const SurahReader(
      {super.key, required this.surah, required this.quranFontSize});

  @override
  State<SurahReader> createState() => _SurahReaderState();
}

class _SurahReaderState extends State<SurahReader> {
  List<AyahData> _ayahs = <AyahData>[];
  bool _loading = true;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() {
      _loading = true;
      _error = false;
    });
    try {
      final Uri uri = Uri.https(
        'api.alquran.cloud',
        '/v1/surah/${widget.surah.number}/editions/quran-uthmani,en.asad,ur.jalandhry',
      );
      final http.Response res =
          await http.get(uri).timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) throw Exception('bad status');
      final Map<String, dynamic> json =
          jsonDecode(res.body) as Map<String, dynamic>;
      final List<dynamic> editions = json['data'] as List<dynamic>;
      if (editions.length < 3) throw Exception('missing editions');

      List<dynamic> ayahsOf(int idx) =>
          (editions[idx] as Map<String, dynamic>)['ayahs'] as List<dynamic>;
      final List<dynamic> ar = ayahsOf(0);
      final List<dynamic> en = ayahsOf(1);
      final List<dynamic> ur = ayahsOf(2);
      int count = ar.length;
      if (en.length < count) count = en.length;
      if (ur.length < count) count = ur.length;

      final List<AyahData> out = <AyahData>[];
      for (int i = 0; i < count; i++) {
        final Map<String, dynamic> a =
            ar[i] as Map<String, dynamic>;
        out.add(AyahData(
          (a['numberInSurah'] as num?)?.toInt() ?? (i + 1),
          (a['text'] ?? '').toString(),
          ((en[i] as Map<String, dynamic>)['text'] ?? '').toString(),
          ((ur[i] as Map<String, dynamic>)['text'] ?? '').toString(),
        ));
      }
      if (!mounted) return;
      setState(() {
        _ayahs = out;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = true;
      });
    }
  }

  Future<void> _bookmark(AyahData a) async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setInt('last_surah', widget.surah.number);
      await prefs.setInt('last_ayah', a.number);
    } catch (_) {}
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Bookmarked: ${widget.surah.english}, Ayah ${a.number}'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.surah.english} - ${widget.surah.arabic}'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kGold))
          : _error
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Could not load this Surah. Check internet and retry.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                      ElevatedButton(
                        onPressed: _fetch,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _ayahs.length,
                  itemBuilder: (BuildContext context, int i) {
                    final AyahData a = _ayahs[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                CircleAvatar(
                                  radius: 13,
                                  backgroundColor: kGold,
                                  child: Text('${a.number}',
                                      style: const TextStyle(
                                          fontSize: 11,
                                          color: Colors.black)),
                                ),
                                const Spacer(),
                                IconButton(
                                  icon: const Icon(Icons.bookmark_border,
                                      color: kGold),
                                  tooltip: 'Bookmark this Ayah',
                                  onPressed: () => _bookmark(a),
                                ),
                              ],
                            ),
                            Text(
                              a.arabic,
                              textAlign: TextAlign.right,
                              textDirection: TextDirection.rtl,
                              style: TextStyle(
                                fontSize: widget.quranFontSize,
                                height: 1.9,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(a.english,
                                style: const TextStyle(fontSize: 15)),
                            const SizedBox(height: 6),
                            Text(
                              a.urdu,
                              textDirection: TextDirection.rtl,
                              textAlign: TextAlign.right,
                              style: const TextStyle(fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

// ------------------------------- Tasbeeh tab -------------------------------

class Dhikr {
  final String english;
  final String arabic;
  const Dhikr(this.english, this.arabic);
}

const List<Dhikr> kDhikr = <Dhikr>[
  Dhikr('SubhanAllah', 'سُبْحَانَ اللَّهِ'),
  Dhikr('Alhamdulillah', 'الْحَمْدُ لِلَّهِ'),
  Dhikr('Allahu Akbar', 'اللَّهُ أَكْبَرُ'),
  Dhikr('Astaghfirullah', 'أَسْتَغْفِرُ اللَّهَ'),
  Dhikr('Darood Sharif',
      'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ'),
];

class TasbeehTab extends StatefulWidget {
  const TasbeehTab({super.key});

  @override
  State<TasbeehTab> createState() => _TasbeehTabState();
}

class _TasbeehTabState extends State<TasbeehTab> {
  int _count = 0;
  int _today = 0;
  int _lifetime = 0;
  int _target = 100;
  int _dhikrIndex = 0;

  String get _todayKey {
    final DateTime n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      final String savedDate = prefs.getString('tasbeeh_date') ?? '';
      setState(() {
        _today = savedDate == _todayKey
            ? (prefs.getInt('tasbeeh_today') ?? 0)
            : 0;
        _count = _today;
        _lifetime = prefs.getInt('tasbeeh_lifetime') ?? 0;
        _target = prefs.getInt('tasbeeh_target') ?? 100;
        if (_target != 33 && _target != 100 && _target != 1000) {
          _target = 100;
        }
        _dhikrIndex = prefs.getInt('tasbeeh_dhikr') ?? 0;
        if (_dhikrIndex < 0 || _dhikrIndex >= kDhikr.length) _dhikrIndex = 0;
      });
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('tasbeeh_date', _todayKey);
      await prefs.setInt('tasbeeh_today', _today);
      await prefs.setInt('tasbeeh_lifetime', _lifetime);
      await prefs.setInt('tasbeeh_target', _target);
      await prefs.setInt('tasbeeh_dhikr', _dhikrIndex);
    } catch (_) {}
  }

  void _increment() {
    HapticFeedback.vibrate();
    setState(() {
      _count++;
      _today++;
      _lifetime++;
    });
    _save();
    if (_count == _target && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Target complete. MashaAllah!')),
      );
    }
  }

  void _reset() {
    setState(() => _count = 0);
  }

  @override
  Widget build(BuildContext context) {
    final Dhikr dhikr = kDhikr[_dhikrIndex];
    final double progress =
        _target == 0 ? 0.0 : (_count / _target).clamp(0.0, 1.0).toDouble();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          children: List<Widget>.generate(kDhikr.length, (int i) {
            return ChoiceChip(
              label: Text(kDhikr[i].english),
              selected: i == _dhikrIndex,
              selectedColor: kGold,
              onSelected: (_) {
                setState(() {
                  _dhikrIndex = i;
                  _count = 0;
                });
                _save();
              },
            );
          }),
        ),
        const SizedBox(height: 16),
        Text(
          dhikr.arabic,
          textAlign: TextAlign.center,
          textDirection: TextDirection.rtl,
          style: const TextStyle(fontSize: 28, height: 1.6),
        ),
        Text(dhikr.english,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, color: Colors.grey)),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('Target: '),
            DropdownButton<int>(
              value: _target,
              items: const <DropdownMenuItem<int>>[
                DropdownMenuItem<int>(value: 33, child: Text('33')),
                DropdownMenuItem<int>(value: 100, child: Text('100')),
                DropdownMenuItem<int>(value: 1000, child: Text('1000')),
              ],
              onChanged: (int? v) {
                if (v == null) return;
                setState(() => _target = v);
                _save();
              },
            ),
          ],
        ),
        const SizedBox(height: 8),
        Center(
          child: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              SizedBox(
                width: 190,
                height: 190,
                child: CircularProgressIndicator(
                  value: progress,
                  strokeWidth: 10,
                  color: kGold,
                  backgroundColor: Colors.grey.shade300,
                ),
              ),
              Text(
                '$_count',
                style: const TextStyle(
                    fontSize: 54, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Center(
          child: SizedBox(
            width: 170,
            height: 64,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kEmerald,
                foregroundColor: kGold,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(32),
                ),
              ),
              onPressed: _increment,
              child: const Text('+  COUNT',
                  style:
                      TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Center(
          child: TextButton(
            onPressed: _reset,
            child: const Text('Reset counter'),
          ),
        ),
        const Divider(height: 28),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Column(
              children: <Widget>[
                Text('$_today',
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                const Text("Today's total"),
              ],
            ),
            Column(
              children: <Widget>[
                Text('$_lifetime',
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                const Text('Lifetime total'),
              ],
            ),
          ],
        ),
      ],
    );
  }
}

// -------------------------------- Qibla tab --------------------------------

const double kKaabaLat = 21.4225;
const double kKaabaLng = 39.8262;

double _rad(double deg) => deg * math.pi / 180.0;
double _deg(double rad) => rad * 180.0 / math.pi;

double qiblaBearing(double lat, double lng) {
  final double phi1 = _rad(lat);
  final double phi2 = _rad(kKaabaLat);
  final double dLng = _rad(kKaabaLng - lng);
  final double y = math.sin(dLng);
  final double x =
      math.cos(phi1) * math.tan(phi2) - math.sin(phi1) * math.cos(dLng);
  double bearing = _deg(math.atan2(y, x));
  if (bearing < 0) bearing += 360;
  return bearing;
}

double distanceToKaabaKm(double lat, double lng) {
  const double earthKm = 6371.0;
  final double dLat = _rad(kKaabaLat - lat);
  final double dLng = _rad(kKaabaLng - lng);
  final double a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(_rad(lat)) *
          math.cos(_rad(kKaabaLat)) *
          math.sin(dLng / 2) *
          math.sin(dLng / 2);
  final double c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  return earthKm * c;
}

class QiblaTab extends StatelessWidget {
  final City city;
  const QiblaTab({super.key, required this.city});

  @override
  Widget build(BuildContext context) {
    final double bearing = qiblaBearing(city.lat, city.lng);
    final double km = distanceToKaabaKm(city.lat, city.lng);
    final bool isMakkah = city.name == 'Makkah';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        const Text(
          'Qibla Direction',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          'From ${city.name}, ${city.country}',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.grey),
        ),
        const SizedBox(height: 20),
        Center(
          child: CustomPaint(
            size: const Size(280, 280),
            painter: QiblaDialPainter(bearing),
          ),
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: <Widget>[
                Text(
                  isMakkah
                      ? 'You are in Makkah - face the Kaaba'
                      : 'Qibla is ${bearing.toStringAsFixed(1)}° from North',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  isMakkah
                      ? 'Distance to Makkah: 0 km'
                      : 'Distance to Makkah: ${km.toStringAsFixed(0)} km',
                  style: const TextStyle(fontSize: 15),
                ),
                const SizedBox(height: 8),
                const Text(
                  'The gold needle points towards the Kaaba. '
                  'Turn until the needle points straight up on your phone '
                  'compass to face the Qibla.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class QiblaDialPainter extends CustomPainter {
  final double bearing;
  QiblaDialPainter(this.bearing);

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2);
    final double radius = size.width / 2 - 8;

    final Paint fill = Paint()..color = kEmerald;
    canvas.drawCircle(center, radius, fill);
    final Paint ring = Paint()
      ..color = kGold
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawCircle(center, radius, ring);

    // Tick marks every 30 degrees.
    final Paint tick = Paint()
      ..color = Colors.white70
      ..strokeWidth = 2;
    for (int d = 0; d < 360; d += 30) {
      final double a = _rad(d.toDouble());
      final Offset from = center +
          Offset(math.sin(a) * (radius - 12), -math.cos(a) * (radius - 12));
      final Offset to =
          center + Offset(math.sin(a) * radius, -math.cos(a) * radius);
      canvas.drawLine(from, to, tick);
    }

    // Cardinal letters.
    _drawLetter(canvas, center, 0, radius - 28, 'N');
    _drawLetter(canvas, center, 90, radius - 28, 'E');
    _drawLetter(canvas, center, 180, radius - 28, 'S');
    _drawLetter(canvas, center, 270, radius - 28, 'W');

    // Qibla needle (gold) towards the bearing.
    final double a = _rad(bearing);
    final Offset tip =
        center + Offset(math.sin(a) * (radius - 34), -math.cos(a) * (radius - 34));
    final Paint needle = Paint()
      ..color = kGold
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(center, tip, needle);

    // Kaaba marker: small black square with a gold band at the tip.
    canvas.save();
    canvas.translate(tip.dx, tip.dy);
    canvas.rotate(a);
    final Paint kaaba = Paint()..color = Colors.black;
    canvas.drawRect(const Rect.fromLTWH(-10, -10, 20, 20), kaaba);
    final Paint band = Paint()..color = kGold;
    canvas.drawRect(const Rect.fromLTWH(-10, -7, 20, 4), band);
    canvas.restore();

    // Centre dot.
    final Paint dot = Paint()..color = Colors.white;
    canvas.drawCircle(center, 5, dot);
  }

  void _drawLetter(
      Canvas canvas, Offset center, double deg, double dist, String letter) {
    final double a = _rad(deg);
    final Offset pos =
        center + Offset(math.sin(a) * dist, -math.cos(a) * dist);
    final TextPainter tp = TextPainter(
      text: TextSpan(
        text: letter,
        style: const TextStyle(
            color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, pos - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(QiblaDialPainter oldDelegate) =>
      oldDelegate.bearing != bearing;
}

// --------------------------------- More tab --------------------------------

class MoreTab extends StatelessWidget {
  final bool isDark;
  final String lang;
  final String fontSize;
  final ValueChanged<bool> onDarkChanged;
  final ValueChanged<String> onLangChanged;
  final ValueChanged<String> onFontChanged;

  const MoreTab({
    super.key,
    required this.isDark,
    required this.lang,
    required this.fontSize,
    required this.onDarkChanged,
    required this.onLangChanged,
    required this.onFontChanged,
  });

  Widget _header(String text) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
      child: Text(
        text,
        style: const TextStyle(
            fontSize: 17, fontWeight: FontWeight.bold, color: kGold),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        _header('Settings'),
        Card(
          child: Column(
            children: <Widget>[
              SwitchListTile(
                title: const Text('Dark Mode'),
                secondary: const Icon(Icons.dark_mode, color: kGold),
                value: isDark,
                onChanged: onDarkChanged,
              ),
              ListTile(
                leading: const Icon(Icons.language, color: kGold),
                title: const Text('Language'),
                trailing: DropdownButton<String>(
                  value: lang,
                  underline: const SizedBox(),
                  items: const <DropdownMenuItem<String>>[
                    DropdownMenuItem<String>(
                        value: 'en', child: Text('English')),
                    DropdownMenuItem<String>(
                        value: 'ur', child: Text('Urdu - اردو')),
                    DropdownMenuItem<String>(
                        value: 'ar', child: Text('Arabic - العربية')),
                  ],
                  onChanged: (String? v) {
                    if (v != null) onLangChanged(v);
                  },
                ),
              ),
              ListTile(
                leading: const Icon(Icons.format_size, color: kGold),
                title: const Text('Quran Font Size'),
                trailing: DropdownButton<String>(
                  value: fontSize,
                  underline: const SizedBox(),
                  items: const <DropdownMenuItem<String>>[
                    DropdownMenuItem<String>(
                        value: 'S', child: Text('Small')),
                    DropdownMenuItem<String>(
                        value: 'M', child: Text('Medium')),
                    DropdownMenuItem<String>(
                        value: 'L', child: Text('Large')),
                  ],
                  onChanged: (String? v) {
                    if (v != null) onFontChanged(v);
                  },
                ),
              ),
            ],
          ),
        ),
        _header("Today's Prayer Tracker"),
        const Card(child: PrayerTracker()),
        _header('Zakat Calculator'),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(12),
            child: ZakatCalculator(),
          ),
        ),
        _header('Masnoon Duas'),
        ...kDuas.map((Dua d) {
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ExpansionTile(
              title: Text(d.title),
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Text(
                        d.arabic,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        style: const TextStyle(fontSize: 21, height: 1.8),
                      ),
                      const SizedBox(height: 8),
                      Text(d.english),
                      const SizedBox(height: 6),
                      Text(
                        d.urdu,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
        const SizedBox(height: 16),
        const Text(
          'Noor - Islamic App v1.0. Prayer times by Aladhan API, '
          'Quran text by AlQuran Cloud API. No ads on the Quran page.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(height: 12),
      ],
    );
  }
}

// ----------------------------- Prayer tracker ------------------------------

class PrayerTracker extends StatefulWidget {
  const PrayerTracker({super.key});

  @override
  State<PrayerTracker> createState() => _PrayerTrackerState();
}

class _PrayerTrackerState extends State<PrayerTracker> {
  static const List<String> _names = <String>[
    'Fajr',
    'Dhuhr',
    'Asr',
    'Maghrib',
    'Isha',
  ];
  final Map<String, bool> _done = <String, bool>{};

  String get _todayKey {
    final DateTime n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  @override
  void initState() {
    super.initState();
    for (final String n in _names) {
      _done[n] = false;
    }
    _load();
  }

  Future<void> _load() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        for (final String n in _names) {
          _done[n] = prefs.getBool('tracker_${_todayKey}_$n') ?? false;
        }
      });
    } catch (_) {}
  }

  Future<void> _set(String name, bool value) async {
    setState(() => _done[name] = value);
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('tracker_${_todayKey}_$name', value);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final int doneCount =
        _done.values.where((bool v) => v).length;
    return Column(
      children: <Widget>[
        ..._names.map((String n) {
          return CheckboxListTile(
            title: Text(n),
            value: _done[n] ?? false,
            activeColor: kEmerald,
            onChanged: (bool? v) => _set(n, v ?? false),
          );
        }),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Row(
            children: <Widget>[
              Expanded(
                child: LinearProgressIndicator(
                  value: _names.isEmpty ? 0.0 : doneCount / _names.length,
                  color: kGold,
                  backgroundColor: Colors.grey.shade300,
                  minHeight: 8,
                ),
              ),
              const SizedBox(width: 10),
              Text('$doneCount / ${_names.length} today'),
            ],
          ),
        ),
      ],
    );
  }
}

// ----------------------------- Zakat calculator ----------------------------

// Nisab and conversion constants (approximate - update for live prices).
const double kNisabGoldGrams = 87.48; // 7.5 tola gold
const double kNisabSilverGrams = 612.36; // 52.5 tola silver
const double kUsdToPkr = 278.0;
const double kSarToPkr = 74.0;

class ZakatCalculator extends StatefulWidget {
  const ZakatCalculator({super.key});

  @override
  State<ZakatCalculator> createState() => _ZakatCalculatorState();
}

class _ZakatCalculatorState extends State<ZakatCalculator> {
  final TextEditingController _goldPrice =
      TextEditingController(text: '27000'); // PKR per gram (editable)
  final TextEditingController _silverPrice =
      TextEditingController(text: '320'); // PKR per gram (editable)
  final TextEditingController _goldGrams = TextEditingController();
  final TextEditingController _silverGrams = TextEditingController();
  final TextEditingController _cash = TextEditingController();
  final TextEditingController _bank = TextEditingController();
  String _result = '';

  @override
  void dispose() {
    _goldPrice.dispose();
    _silverPrice.dispose();
    _goldGrams.dispose();
    _silverGrams.dispose();
    _cash.dispose();
    _bank.dispose();
    super.dispose();
  }

  double _num(TextEditingController c) =>
      double.tryParse(c.text.trim().replaceAll(',', '')) ?? 0;

  String _fmt(double v) {
    final String s = v.toStringAsFixed(2);
    return s.replaceAllMapped(
      RegExp(r'(\d)(?=(\d{3})+\.)'),
      (Match m) => '${m[1]},',
    );
  }

  void _calculate() {
    final double goldValue = _num(_goldGrams) * _num(_goldPrice);
    final double silverValue = _num(_silverGrams) * _num(_silverPrice);
    final double total = goldValue + silverValue + _num(_cash) + _num(_bank);
    final double nisabBySilver = kNisabSilverGrams * _num(_silverPrice);
    final double nisabByGold = kNisabGoldGrams * _num(_goldPrice);
    final double nisab =
        nisabBySilver > 0 ? nisabBySilver : nisabByGold;

    setState(() {
      if (total <= 0) {
        _result = 'Enter your gold, silver, cash or bank balance first.';
      } else if (nisab > 0 && total < nisab) {
        _result = 'Total wealth: PKR ${_fmt(total)}\n'
            'Nisab (silver): PKR ${_fmt(nisab)}\n'
            'Your wealth is below nisab, so Zakat is not due yet.';
      } else {
        final double zakat = total * 0.025;
        final double usd = zakat / kUsdToPkr;
        final double sar = zakat / kSarToPkr;
        _result = 'Total zakatable wealth: PKR ${_fmt(total)}\n'
            'Nisab (silver): PKR ${_fmt(nisab)} - Zakat is due\n\n'
            'ZAKAT (2.5%):\n'
            'PKR ${_fmt(zakat)}\n'
            'USD ${_fmt(usd)}\n'
            'SAR ${_fmt(sar)}';
      }
    });
  }

  Widget _field(String label, TextEditingController c) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        keyboardType:
            const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const Text(
          'Zakat is 2.5% of zakatable wealth held for one lunar year, '
          'when it reaches nisab (87.48g gold or 612.36g silver). '
          'Prices below are editable - set todays rate in your city.',
          style: TextStyle(fontSize: 13, color: Colors.grey),
        ),
        const SizedBox(height: 12),
        _field('Gold price - PKR per gram', _goldPrice),
        _field('Silver price - PKR per gram', _silverPrice),
        _field('Gold you own - grams', _goldGrams),
        _field('Silver you own - grams', _silverGrams),
        _field('Cash in hand - PKR', _cash),
        _field('Bank balance - PKR', _bank),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: kEmerald,
            foregroundColor: kGold,
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
          onPressed: _calculate,
          child: const Text('Calculate Zakat',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        if (_result.isNotEmpty) ...<Widget>[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: kCream,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: kGold),
            ),
            child: Text(_result,
                style: const TextStyle(color: Colors.black87, height: 1.5)),
          ),
        ],
      ],
    );
  }
}
